/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServeurClient;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.WindowEvent;
import java.util.Enumeration;
import java.util.Vector;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

/**
 *
 * @author markk
 */
public class EcrivainIHM extends Frame{
    Panel panel1 = new Panel();
	BorderLayout borderLayout1 = new BorderLayout();
	Button bArret = new Button();
	Label texte = new Label();
	Panel panel2 = new Panel();
	Label blanc = new Label();
	TextField messageText = new TextField();
	Vector ecrivains = new Vector();

	// Construction
	public EcrivainIHM(String title) {
		super(title);
		try {
			jbInit();
			texte.setText(title);
			pack();
			show();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public EcrivainIHM() {
		this("");
	}

	public EcrivainIHM(String title, EcrivainInterface e) {
		this(title);
		this.addEcrivain(e);
	}

	// méthode permettant d'ajouter le message dans le Vector ecrivains
	public void addEcrivain(EcrivainInterface e) {
		ecrivains.addElement(e);
	}

	// méthode pour afficher le contenu du vecteur
	void envoieMessage(String mess) {
		for (Enumeration e = ecrivains.elements(); e.hasMoreElements();)
			((EcrivainInterface) e.nextElement()).envoieMessage(this.getTitle()
					+ " : " + mess);
	}

	// méthode pour créer l'interface HM
	void jbInit() throws Exception {
		panel1.setLayout(borderLayout1);
		bArret.setLabel("Arret !");
		bArret.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bArret_actionPerformed(e);
			}
		});
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				this_windowClosing(e);
			}
		});
		blanc.setText("                                                         ");
		messageText.setColumns(50);
		messageText.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				messageText_actionPerformed(e);
			}
		});
		this.add(panel1, BorderLayout.NORTH);
		panel1.add(panel2, BorderLayout.NORTH);
		panel2.add(texte, null);
		panel2.add(bArret, null);
		panel2.add(blanc, null);
		panel1.add(messageText, BorderLayout.SOUTH);
	}

	// gérer le quittement du programme
	void bArret_actionPerformed(ActionEvent e) {
		System.exit(1);
	}

	void this_windowClosing(WindowEvent e) {
		System.exit(1);
	}

	//
	void messageText_actionPerformed(ActionEvent e) {
		this.envoieMessage(messageText.getText());
		messageText.setText("");
	}
}
