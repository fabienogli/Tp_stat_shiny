/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServeurClient;

import static ServeurClient.ServeurConcurrent.BUF_SIZE;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;

/**
 *
 * @author markk
 */
public class ServeurRequete implements Runnable {
    final static int BUF_SIZE = 1024;
    private int numClient = 0;
    private DatagramSocket clientSocket;
    String mess = "";
    InetAddress clientAddress;
    int clientPort;
    boolean stop = false;
   // BufferedReader in;
    //PrintWriter out;

    public ServeurRequete(DatagramSocket s,InetAddress addr,int port) throws IOException {
        this.clientSocket = s;
        this.clientAddress=addr;
        this.clientPort=port;
        //in = new BufferedReader(new InputStreamReader(s.getInputStream()));
        //out = new PrintWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
        numClient = ServeurConcurrent.addClient(s);

    }

    public void run() {
        try {
            byte[] buf = new byte[BUF_SIZE];
            //byte[] buf2 = new byte[BUF_SIZE];
// Attente infinie des connexions entrantes    
            ServeurConcurrent.serv.affiche("REQ(" + numClient + ") : Ouverture" + '\n');
            //informer le clientSocket
            String mess = "je touvres un port";
            String mess2 = "ton message a ete recu";
            buf = mess.getBytes();
            byte[] buf2 = mess2.getBytes();
            DatagramPacket response = new DatagramPacket(buf, buf.length,clientAddress,clientPort); 
            clientSocket.send(response);           
            while (!stop) {
                DatagramPacket receivePacket = new DatagramPacket(buf, buf.length); 
    	        clientSocket.receive(receivePacket);
// Protocole de communication     
                mess = new String(receivePacket.getData( ), receivePacket.getOffset( ), receivePacket.getLength( ));
                ///System.out.println(mess);
                ServeurConcurrent.serv.affiche("REQ(" + numClient + ") : Reception de : " + mess + '\n');
                DatagramPacket response2 = new DatagramPacket(buf2, buf2.length,clientAddress,clientPort); 
                clientSocket.send(response2); 
// Fermeture de la connexion 
            }
        } // Traitement des erreurs d’entées / sorties
        catch (IOException ioe) {
        } finally {
            // fermeture du socket avant la fin du traitement du clientSocket
            clientSocket.close();
            ServeurConcurrent.serv.affiche("REQ(" + numClient + ") : Fermeture");
        }

    }
}
