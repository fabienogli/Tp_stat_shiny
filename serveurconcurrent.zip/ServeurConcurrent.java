/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServeurClient;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

/**
 *
 * @author markk
 */
public class ServeurConcurrent {
    final static int BUF_SIZE = 1024;
    private static Vector tabClients = new Vector<ServeurRequete>();
    // contiendra tous les flux de sortie vers les clients   
    private static int nbClients = 0;
    static ServIHM serv;
    ServerSocket sock;
    Socket client;
    String mess, message;
    final static int port = 6000;

    public ServeurConcurrent(ServIHM serv) throws IOException {
        this.serv = serv;
    }
    // Un constructeur qui recevra en argument un objet de la classe ServIHM  

    synchronized public static int addClient(DatagramSocket s) {
        nbClients++; // un client de plus       
        tabClients.addElement(s); // on ajoute le nouveau flux de sortie au tableau      
        return tabClients.size(); // on retourne le numéro du client ajouté    
    }

    public void exec() throws IOException {
        //Socket client;
        // Ouverture du port de réception des demandes de connexions   
        //ServerSocket sock;
        //sock = new ServerSocket(6000);
        boolean stop = false;
        byte[] buf = new byte[BUF_SIZE];       // zone de r�ception
        int port = 6000;  // port de r�ception
        DatagramSocket serverSocket = new DatagramSocket(port);
        System.out.println("je suis ici1");
// Attente infinie des connexions entrantes   
        while (!stop) {
            //code permettant de recevoir le packet UDP 
    	    DatagramPacket receivePacket = new DatagramPacket(buf, buf.length); 
    	    serverSocket.receive(receivePacket);
            System.out.println("je suis ici2");
            //client = sock.accept();
            ServeurRequete s = new ServeurRequete(new DatagramSocket(),receivePacket.getAddress(),receivePacket.getPort());
            Thread threadService = new Thread(s);
            threadService.start();
        }
        sock.close();
    }

    public static void main(String[] args) throws IOException {
        ServIHM fen = new ServIHM("Serveur Concurrent");
        (new ServeurConcurrent(fen)).exec();
    }
}
