/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServeurClient;

import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;

/**
 *
 * @author markk
 */
public class Client implements EcrivainInterface, Runnable {

    final static int BUF_SIZE = 1024;
    private InetAddress adresse;
    private Socket sock;
    DatagramSocket clientSocket;
    private int port;
    //private PrintWriter out;
    // construction
    // lancer le client

    Client(String serveur) {
        System.out.println("Lancement d'un client vers : " + serveur);
        try {
            adresse = InetAddress.getByName(serveur);
            //sock = new Socket(adresse, 6000);
            clientSocket = new DatagramSocket();
            port = 6000;
            //out = new PrintWriter(
            //new OutputStreamWriter(sock.getOutputStream()), true);
            // true permet de faire de l'auto-flush.
        } catch (Exception e) {
            System.out.println(e);

        }
        Thread threadService = new Thread(this);
        threadService.start();
        connexion();
    }

    Client() {
        this("localhost");
    }

    // méthode permettant le client d'envoyer un message vers le flux sortant
    // méthode inhérité de la classe EcrivainInterface
    public void envoieMessage(String mess) {
        //on recupere l'adresse IP correspondant au 1er argument
        //InetAddress addr = InetAddress.getByName(args[0]);
        //on recupere le numero de port qui est le 2 eme argument 
        //on le convertit en entier
        //int port = Integer.parseInt(args[1]);
        System.out.println("Emission du message : " + mess);
        byte[] buf = mess.getBytes();
        //on construit le datagramme � envoyer
        DatagramPacket sendPacket = new DatagramPacket(buf, buf.length, adresse, port);
        //on affiche l'adresse IP et le port, local des sockets utilis�s
        System.out.println("Un packet pour " + sendPacket.getAddress() + " port " + sendPacket.getPort());
        //affiche la taille du paquet
        System.out.println("il y a " + sendPacket.getLength() + " bytes dans le packet");
        //affiche le message � envoyer
        System.out.println(new String(sendPacket.getData(), sendPacket.getOffset(), sendPacket.getLength()));
        //on envoie le paquet

        try {
            clientSocket.send(sendPacket);
            //out.println(mess);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    public void connexion(){
    envoieMessage("connexion");
    }

    // initialisation de client en tapant le nom, sinon le client sera nommé
    // "Ecrivain"
    public static void main(String argv[]) {
        Client client;
        String name;
        switch (argv.length) {
            case 1:
                name = argv[0];
                client = new Client();
                break;
            case 2:
                name = argv[0];
                client = new Client(argv[1]);
                break;
            default:
                name = "Client";
                client = new Client();
                break;
        }
        EcrivainIHM ecrivainIHM = new EcrivainIHM(name, client);

    }

    @Override
    public void run() {
        try {
            byte[] buf = new byte[BUF_SIZE];       // zone de r�ception
            //int port = Integer.parseInt(args[0]);  // port de r�ception
            //DatagramSocket serverSocket = new DatagramSocket(port);

            while (true) {
                //code permettant de recevoir le packet UDP 
                DatagramPacket receivePacket = new DatagramPacket(buf, buf.length);
                clientSocket.receive(receivePacket);
                this.port = receivePacket.getPort();
                // affichage son contenu (et l'adresse et le port d'origine)
                System.out.println(" Un packet de " + receivePacket.getAddress() + " port " + receivePacket.getPort());
                System.out.println("il y a " + receivePacket.getLength() + " bytes dans le packet");
                System.out.println(new String(receivePacket.getData(), receivePacket.getOffset(), receivePacket.getLength()));
                // Fin de r�ception d'un packet
            }
        } catch (Exception e) {
            System.err.println("Erreur � l'ex�cution :");
            e.printStackTrace(System.err);
        }
    }
}
