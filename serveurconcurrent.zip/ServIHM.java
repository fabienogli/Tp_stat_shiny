/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServeurClient;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.ScrollPane;
import java.awt.TextArea;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
 *
 * @author markk
 */
public class ServIHM extends Frame{
    // attributs de l'IHM :
	Panel panel1 = new Panel(); // Fenêtre principale
	BorderLayout borderLayout1 = new BorderLayout(); // Gestionnaire d'aspect
	Button bArret = new Button(); // Bouton d'arrêt du serveur
	Label texte = new Label(); // Affichage du nom
	Panel panel2 = new Panel(); // Panneau d'affichage
	ScrollPane scrollPane1 = new ScrollPane();
	TextArea messages = new TextArea(); // Zone d'affichage
	Label blanc = new Label();

	// Méthode permettant d'afficher un message dans la zone texte
	public void affiche(String mess) {
		messages.append(mess);
	}

	// Construction
	public ServIHM(String title) {
		super(title);
		try {
			jbInit();
			texte.setText(title);
			pack();
			show();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public ServIHM() {
		this("");
	}

	// Initialisation de l'IHM
	void jbInit() throws Exception {
		panel1.setLayout(borderLayout1);
		bArret.setLabel("Arret !");
		bArret.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bArret_actionPerformed(e);
			}
		});
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				this_windowClosing(e);
			}
		});
		blanc.setText("                                                               ");
		this.setTitle("                         ");
		this.add(panel1, BorderLayout.CENTER);
		panel1.add(panel2, BorderLayout.NORTH);
		panel2.add(texte, null);
		panel2.add(bArret, null);
		panel2.add(blanc, null);
		panel1.add(scrollPane1, BorderLayout.CENTER);
		scrollPane1.add(messages, null);
	}

	// ACTION du bouton stop : arrêt forcé de l'application
	void bArret_actionPerformed(ActionEvent e) {
		System.exit(1);
	}

	// Idem pour la fermeture forcée de la fenêtre
	void this_windowClosing(WindowEvent e) {
		System.exit(1);
	}
}
